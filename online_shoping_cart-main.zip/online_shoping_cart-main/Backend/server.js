import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { create } from "xmlbuilder2";

const app = express();
app.use(cors());
app.use(express.json());

// ✅ MongoDB connection
mongoose
  .connect("mongodb://127.0.0.1:27017/shoppingcart")
  .then(() => console.log("✅ MongoDB Connected Successfully"))
  .catch((err) => console.log(err));

// ✅ Models
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  role: { type: String, default: "customer" },
});

const productSchema = new mongoose.Schema({
  name: String,
  price: Number,
  image: String, // 🆕 product photo link
});

const orderSchema = new mongoose.Schema({
  userEmail: String,
  items: Array,
  total: Number,
  xml: String,
});

const User = mongoose.model("User", userSchema);
const Product = mongoose.model("Product", productSchema);
const Order = mongoose.model("Order", orderSchema);

// ✅ Routes
app.get("/", (req, res) => {
  res.send("✅ Backend working successfully!");
});

// Register
app.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const hash = await bcrypt.hash(password, 10);
    await User.create({ name, email, password: hash });
    res.send("User Registered");
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Login
app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).send("User not found");
  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(400).send("Wrong password");
  const token = jwt.sign({ email }, "secret");
  res.json({ token });
});

// ✅ Add product (with image)
app.post("/add-product", async (req, res) => {
  const { name, price, image } = req.body;
  if (!name || !price || !image) return res.status(400).send("Missing fields");
  await Product.create({ name, price, image });
  res.send("Product Added Successfully");
});

// ✅ Get products
app.get("/products", async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

// ✅ Place order (saved with XML)
app.post("/order", async (req, res) => {
  const { userEmail, items } = req.body;
  const total = items.reduce((sum, i) => sum + i.price, 0);
  const xml = create({ Order: { userEmail, total, items } }).end({ prettyPrint: true });
  await Order.create({ userEmail, items, total, xml });
  res.send("Order Placed (saved in XML format)");
});

// ✅ Start server
app.listen(5000, () => console.log("✅ Backend running on http://localhost:5000"));
