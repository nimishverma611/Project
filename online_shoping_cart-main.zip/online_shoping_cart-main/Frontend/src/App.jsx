import { BrowserRouter, Routes, Route, Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";

// ✅ Login Page
function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      await axios.post("http://localhost:5000/login", { email, password });
      localStorage.setItem("email", email);
      alert("Login successful!");
      navigate("/shop");
    } catch {
      alert("Invalid login details");
    }
  };

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h2>Login Page</h2>
      <input
        placeholder="Email"
        onChange={(e) => setEmail(e.target.value)}
        style={{ padding: "10px", margin: "5px", width: "250px" }}
      />
      <br />
      <input
        type="password"
        placeholder="Password"
        onChange={(e) => setPassword(e.target.value)}
        style={{ padding: "10px", margin: "5px", width: "250px" }}
      />
      <br />
      <button
        onClick={handleLogin}
        style={{
          background: "#007bff",
          color: "white",
          padding: "10px 20px",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Login
      </button>
    </div>
  );
}

// ✅ Shop Page
function Shop() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const email = localStorage.getItem("email");

  useEffect(() => {
    axios.get("http://localhost:5000/products").then((res) => setProducts(res.data));
  }, []);

  const addToCart = (p) => setCart([...cart, p]);

  const checkout = async () => {
    await axios.post("http://localhost:5000/order", { userEmail: email, items: cart });
    alert("Order placed successfully!");
    setCart([]);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>🛍️ Products</h2>
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "20px",
          justifyContent: "center",
        }}
      >
        {products.map((p) => (
          <div
            key={p._id}
            style={{
              border: "1px solid #ddd",
              borderRadius: "10px",
              padding: "10px",
              width: "230px",
              textAlign: "center",
              background: "#fff",
              boxShadow: "0 3px 8px rgba(0,0,0,0.1)",
            }}
          >
            <img
              src={p.image}
              alt={p.name}
              style={{
                width: "100%",
                height: "180px",
                objectFit: "cover",
                borderRadius: "10px",
              }}
            />
            <h3 style={{ margin: "10px 0" }}>{p.name}</h3>
            <p>₹{p.price}</p>
            <button
              style={{
                background: "#007bff",
                color: "white",
                border: "none",
                padding: "8px 15px",
                borderRadius: "5px",
                cursor: "pointer",
              }}
              onClick={() => addToCart(p)}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>

      <h3 style={{ marginTop: "30px" }}>🛒 Cart ({cart.length})</h3>
      <button
        onClick={checkout}
        style={{
          background: "green",
          color: "white",
          padding: "10px 20px",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Checkout
      </button>
    </div>
  );
}

// ✅ App Component (Main Router)
export default function App() {
  return (
    <BrowserRouter>
      <nav style={{ background: "#eee", padding: "10px", textAlign: "center" }}>
        <Link to="/" style={{ margin: "10px" }}>Login</Link>
        <Link to="/shop" style={{ margin: "10px" }}>Shop</Link>
      </nav>

      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/shop" element={<Shop />} />
      </Routes>
    </BrowserRouter>
  );
}
